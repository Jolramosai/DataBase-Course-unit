USE stand;
/*Lista de carros a gasóleo*/
SELECT * FROM Carro
    WHERE Carro.Combustivel = 'Gasolina';
/*Lista de carros da marca Volkswagen com mais de */
SELECT * FROM Carro
	WHERE Fabricante='Volkswagen' AND Potencia > 200;
/* Nomes dos clietnes que compraram carros de gama alta (acima de 30000 euros)*/
SELECT NomeProprio, Apelido
	FROM Cliente
	INNER JOIN Venda ON Venda.Cliente_NRIDCivil = Cliente.NRIDCivil
	WHERE PrecoDeVenda > 30000;
/* Carros mais requisitados para aluguer */
SELECT Carro_NumeroChassis, Fabricante, Modelo, sum(QuilometragemRealizada), count(*) as NumeroTotalAlugueres, sum(QuilometragemRealizada)/count(*) as MediaKmPorViagem 
	FROM stand.Aluguer 
	INNER JOIN Carro ON Carro_NumeroChassis=NumeroChassis
GROUP BY Carro_NumeroChassis
ORDER BY NumeroTotalAlugueres DESC;
/* Lista de Clientes que mais requisitaram carros para aluguer e estatísticas associadas */
SELECT  concat(NomeProprio, " ", Cliente.Apelido) AS NomeCliente, count(*) AS NrAlugueresTotal, sum(QuilometragemRealizada)/count(*) AS MediaKmsViagem,
	sum(QuilometragemRealizada) AS TotalKmsFeitos, sum(datediff(FimDeAluguer, InicioDeAluguer)) AS TotalDias, 
    sum(QuilometragemRealizada)/sum(datediff(FimDeAluguer, InicioDeAluguer)) AS MediaDiariaKms,
    sum((Mensalidade/30)*datediff(FimDeAluguer, InicioDeAluguer)) AS ValorTotalDispendido 
	FROM stand.Aluguer 
	INNER JOIN Cliente ON NRIDCivil=Cliente_NRIDCivil
GROUP BY Cliente_NRIDCivil
ORDER BY NrAlugueresTotal DESC;
/* Lista de vendas com os clientes que optaram por comprar carros com KMs feitos em aluguer, ordenadas pelo Nr de vezes que o carro foi alugado */
SELECT ID, PrecoDeVenda, Fabricante, Modelo, NrVezesAlugado, QuilometragemRealizadaEmAluguer, concat(NomeProprio, " ", Apelido) AS Cliente 
	FROM Venda
	INNER JOIN (
		SELECT Carro_NumeroChassis, count(*) AS NrVezesAlugado, sum(QuilometragemRealizada) AS QuilometragemRealizadaEmAluguer FROM Aluguer
		GROUP BY Carro_NumeroChassis
	) AS A ON A.Carro_NumeroChassis = Venda.Carro_NumeroChassis
    INNER JOIN Carro ON Venda.Carro_NumeroChassis = NumeroChassis
    INNER JOIN Cliente ON Venda.Cliente_NRIDCivil = Cliente.NRIDCivil
ORDER BY NrVezesAlugado DESC;
/*###############################*/
/* Procedure Total de Quilómetros feitos em Aluguer de um Carro. Exemplo: */
DROP PROCEDURE IF EXISTS prQuilometragemCarroAluguer;
DELIMITER $$
CREATE PROCEDURE prQuilometragemCarroAluguer (inputChassisCarro varchar(45))
BEGIN 
	SELECT sum(QuilometragemRealizada) AS QuilometragemRealizadaEmAluguer FROM Aluguer
	GROUP BY Carro_NumeroChassis
	HAVING Carro_NumeroChassis = inputChassisCarro;
END$$
DELIMITER ;
/* Procedure Procura de um Carro por marca/modelo Exemplo: */
DROP PROCEDURE IF EXISTS prProcuraCarro;
DELIMITER $$
CREATE PROCEDURE prProcuraCarro (inputMarcaModelo varchar(90))
BEGIN 
	SELECT * FROM Carro
	WHERE upper(concat(Carro.Fabricante, ' ' ,Carro.Modelo)) LIKE concat('%', upper(inputMarcaModelo), '%');
END$$
DELIMITER ;
/*###############################*/
/* View Total Facturado por cada carro */
DROP VIEW IF EXISTS vwTotalFaturadoPorCarro;
CREATE VIEW vwTotalFaturadoPorCarro
AS 
	SELECT NumeroChassis, Fabricante, Modelo, IFNULL(PrecoDeVenda,CustoDoFornecedor)-IFNULL(ValorDeAbate,0)-CustoDoFornecedor AS FacturadoVenda,
    FNULL(FacturadoEmAluguer,0) AS FacturadoAluguer, IFNULL(PrecoDeVenda,CustoDoFornecedor)-IFNULL(ValorDeAbate,0)-CustoDoFornecedor + IFNULL(FacturadoEmAluguer,0) AS Total
	FROM Carro
	LEFT JOIN Venda ON Carro.NumeroChassis = Venda.Carro_NumeroChassis
	LEFT JOIN ( 
			SELECT Carro_NumeroChassis, sum((Mensalidade/30)*datediff(FimDeAluguer, InicioDeAluguer)) as FacturadoEmAluguer 
			FROM Aluguer GROUP BY Carro_NumeroChassis
		) AS A 
	ON Carro.NumeroChassis = A.Carro_NumeroChassis;
/* View Carros ainda não vendidos */
DROP VIEW IF EXISTS vwCarrosNaoVendidos;
CREATE VIEW vwCarrosNaoVendidos AS
	SELECT * FROM Carro
    LEFT JOIN Venda ON Venda.Carro_NumeroChassis=Carro.NumeroChassis
    WHERE Venda.Carro_NumeroChassis IS NULL;
/*###############################*/
/* Função lucro total. (Assume a existência da view vwTotalFaturadoPorCarro guardada na bd) Exemplo: */
DROP FUNCTION IF EXISTS fcLucro;
DELIMITER $$
CREATE FUNCTION fcLucro () RETURNS INT
BEGIN
    DECLARE resultado INT;
    SELECT sum(Total) INTO resultado FROM vwTotalFaturadoPorCarro;
    RETURN resultado;
END $$
Delimiter ;
/*###############################*/
/* Trigger para actualizar quilometragem na tabela Carro, fazendo o somatório da QuilometragemRealizada em Aluguer, sempre que uma linha em Aluguer é modificada */
DROP TRIGGER IF EXISTS trUpdateCarroQuilometragem;
DELIMITER $$
CREATE TRIGGER trUpdateCarroQuilometragem AFTER UPDATE ON Aluguer
FOR EACH ROW
BEGIN
	declare kms INT(11);
	SELECT sum(QuilometragemRealizada) INTO kms FROM Aluguer
	GROUP BY Carro_NumeroChassis
	HAVING Carro_NumeroChassis = OLD.Carro_NumeroChassis;
	UPDATE Carro SET Carro.Quilometragem = kms WHERE Carro.NumeroChassis = NEW.Carro_NumeroChassis;
END$$
DELIMITER ;
/*###############################*/
/* Transacção Registo de uma Venda */
DROP PROCEDURE IF EXISTS trVenda;
DELIMITER $$
CREATE PROCEDURE trVenda (inputNRIDCivil varchar(45), inputNumeroChassis varchar(45), inputPrecoDeVenda INT, inputValorDeAbate INT)
BEGIN 
    DECLARE ErroTransacao BOOL DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET ErroTransacao = 1;
    START TRANSACTION;
		SELECT count(*) INTO ErroTransacao FROM Venda WHERE Venda.Carro_NumeroChassis = inputNumeroChassis;
		INSERT INTO Venda (PrecoDeVenda, DatadeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis) 
			VALUES (inputPrecoDeVenda, now(), inputValorDeAbate, inputNRIDCivil, inputNumeroChassis);
    IF ErroTransacao THEN
        ROLLBACK;
        SELECT 'Erro a registar Venda' AS ERRO;
    ELSE
        COMMIT;
    END IF;
END$$
DELIMITER ;
/*
Partes sem headers exemplificadas no relatório, exemplo:
		SELECT count(*) INTO ErroTransacao FROM Venda WHERE Venda.Carro_NumeroChassis = inputNumeroChassis;
		INSERT INTO Venda (PrecoDeVenda, DatadeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis) 
			VALUES (inputPrecoDeVenda, now(), inputValorDeAbate, inputNRIDCivil, inputNumeroChassis)
*/
/* Transacção inserção de cliente com respectivo Aluguer  */
DROP PROCEDURE IF EXISTS trInsereAluguerDeClienteNovo;
DELIMITER $$
CREATE PROCEDURE trInsereAluguerDeClienteNovo (
							nrIDCivil varchar(45), nomeProprio varchar(45), apelido varchar(45) , nib INT, datadeNascimento DATE, codigoPostal varchar(45), email varchar(45),
							mensalidade INT, inicioDeAluguer DATE, fimDeAluguer DATE, quilometragemRealizada INT, nrChassis varchar(45))
BEGIN 
    DECLARE ErroTransacaoClienteExistente  BOOL DEFAULT 0;
    DECLARE ErroTransacaoCarroExistente    BOOL DEFAULT 0;
    START TRANSACTION;
		Select count(*) INTO ErroTransacaoClienteExistente FROM Cliente WHERE Cliente.NRIDCivil = nrIDCivil;
        INSERT IGNORE INTO Cliente (NRIDCivil, NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, Email) 
			VALUES (nrIDCivil, nomeProprio , apelido, nib, datadeNascimento, codigoPostal, email);
        Select count(*) INTO ErroTransacaoCarroExistente FROM Aluguer WHERE Aluguer.Carro_NumeroChassis = nrChassis;
		INSERT IGNORE INTO Aluguer (Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis) 
				VALUES (mensalidade, inicioDeAluguer , fimDeAluguer ,quilometragemRealizada ,nrIDCivil, nrChassis);
        IF ErroTransacaoClienteExistente THEN
			ROLLBACK;
			SELECT 'ERRO Cliente' AS ERRO;
        ELSEIF ErroTransacaoCarroExistente THEN
			ROLLBACK;
			SELECT 'ERRO CARRO' AS ERRO;
		ELSE
			-- ROLLBACK;
			COMMIT;
		END IF;
END$$
DELIMITER ;
/* Transacção inserção de cliente com a respetiva Compra  */
DROP PROCEDURE IF EXISTS trUpdateAluguerDeCliente;
DELIMITER $$
CREATE PROCEDURE trUpdateAluguerDeCliente ( nrIDCivil varchar(45), fimDeAluguer DATE, quilometragemRealizada INT, nrChassis varchar(45))
BEGIN 
    START TRANSACTION;
    /*Existe um trigger que aumenta a quilometragem no carro*/
		UPDATE IGNORE Aluguer
		SET Aluguer.FimDeAluguer = fimDeAluguer AND Aluguer.QuilometragemRealizada = quilometragemRealizada
		WHERE Aluguer.Carro_NumeroChassis = nrChassis AND Aluguer.Cliente_NRIDCivil = nrIDCivil;
END $$
DELIMITER ;
/*###############################*/
CREATE USER 'Funcionario'@'localhost' IDENTIFIED BY 'funcionario';
GRANT ALL PRIVILEGES ON stand.* TO 'Funcionario'@'localhost';
FLUSH PRIVILEGES;
CREATE USER 'Cliente'@'localhost' IDENTIFIED BY 'cliente';
GRANT UPDATE, SELECT ON stand.* TO 'Cliente'@'localhost';
FLUSH PRIVILEGES;
