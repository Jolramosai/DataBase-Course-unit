USE stand;

-- Povoamento da tabela "Carro"
INSERT INTO Carro
   (NumeroChassis, DataDeMatricula, Cor, Fabricante, Modelo, MSRP, CustoDoFornecedor, Combustivel, Cilindrada, Potencia, Quilometragem)
   VALUES
		('43SJ8232RD', '2017/03/05', 'Preto',  'Seat',       'Leon',       26500, 23531, 'Gasóleo',  1968, 150, 0),
		('58VC213EDZ', '2017/01/22', 'Azul',   'Volkswagen', 'Polo GTI',   23999, 19823, 'Gasolina', 1482, 140, 0),
		('78NF3EV215', '2016/12/10', 'Branco', 'Audi',       'A3',         24900, 21187, 'Gasolina', 1398, 140, 1800),
		('21E1CXV333', '2017/04/10', 'Branco', 'Volkswagen', 'Golf',       19990, 17410, 'Gasóleo',  1581, 140, 0),
		('40RDF7E00R', '2016/10/25', 'Cinza',  'Audi',       'A4',         41500, 38423, 'Gasolina', 1984, 190, 1200),
		('51ZS9843CC', '2017/01/22', 'Cinza',  'Volkswagen', 'Golf R',     39900, 36543, 'Gasolina', 1984, 360, 0),
		('08W7XC224D', '2017/01/17', 'Preto',  'Audi',       'TT',         42990, 39876, 'Gasolina', 1984, 230, 300),
		('98WE22CV4F', '2017/02/19', 'Preto',  'Audi',       'A5',         44990, 40404, 'Gasolina', 1984, 252, 0),
		('983RVC78ML', '2017/04/15', 'Preto',  'Seat',       'Leon Cupra', 28999, 23456, 'Gasolina', 1984, 300, 1700),
       
		('70DS564723', '2016/03/05', 'Preto'  ,  'Audi'        ,	'S1' 		,	34287,	30876,	'Gasóleo' ,	1968,	130,	7679),
		('80FE238954', '2016/01/22', 'Azul'   ,  'Audi'        ,	'A4'  		,	27865,	23788,	'Gasóleo' ,	1587,	130,	3987),
		('85TGJGKF76', '2016/12/10', 'Verde'  ,  'Audi'        ,	'A3'      	,	36544,	34637,	'Gasolina',	1398,	140,	1800),
		('87UYCNCN98', '2016/04/10', 'Branco' ,  'Volkswagen'  ,	'Golf'    	,	19990, 	17410, 	'Gasóleo' , 1581, 	140,	0),
		('23IUBHDS12', '2017/10/25', 'Cinza'  ,  'Seat'        ,	'Ibiza'    	,	24534,	18423,	'Gasolina',	1587,	110,	1200),
		('65KJ9BVBSS', '2016/11/03', 'Cinza'  ,  'Volkswagen'  ,	'Golf R'    ,	39900, 	36543, 	'Gasolina', 1984, 	360,	1002),
		('94ASXC22ER', '2017/01/17', 'Branco' ,  'Volkswagen'  ,	'Passat CC' ,	42990,	39876,	'Gasolina',	1587,	150,	300);
       
-- Povoamento da tabela "Cliente"
INSERT INTO Cliente
   (NRIDCivil , NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, email)
   VALUES
		('124285589-2-XS2', 'Zlatan', 'Ibra',     1234923,   '1981/11/03', '9999-99-99 Zlatanpost', 'zlatan@ibra.com'),
		('342442149-8-DW1', 'Rui',    'Vitória',  4950312,   '1940/03/10', '1450-43-21 Champ',      'rv@gmail.com'),
		('723009453-9-HG3', 'Jorge',  'Jesus',    2334454,   '1954/07/24', '5543-78-90 Bola',       'jj@gorila.com'),
		('335589029-1-RE0', 'Bruno',  'Carvalho', 1894923,   '1972/02/08', '5543-78-59 Bolinha',    'br@sportingcp.com'),
		('578923234-7-LP4', 'Pinto',  'Costa',    7845920,   '1937/12/28', '7439-33-33 Penta',      'pc@fcporto.com'),

		('327438434-2-MP3', 'Nando'   ,  'Vale'     , 5131231, '1974/05/25', '1234-56-78 Gotham', 'nico@bromail.com') ,
		('657485493-6-DI0', 'Joel'    ,  'Sousa'    , 3653221, '1945/08/10', '1111-43-21 Santa Marta das Cortiças', 'jsp@liberdade.com'),
		('344754322-4-HB2', 'Diogo'   ,  'Teixeira' , 9876543, '1951/07/31', '5040-70-90 Alpes de Baixo', 'tuxinho51@gmail.com'),
		('324475465-1-CD3', 'Celso'   ,  'Carvalho' , 3447729, '1975/02/03', '5222-22-59 Penacova', 'celso_1@gmail.com'),
		('743845321-0-LP2', 'Armando' ,  'Francisco', 9009876, '1997/12/25', '7765-31-32 Abstatt', 'acisco@live.com'),
        ('126637453-6-KL3', 'João'    ,  'Ferreira' , 3767483, '1967/12/11', '3439-73-33 Serew', 'joao_fr@yahoo.com');

-- Povoamento da tabela "Telefone"
INSERT INTO Telefone
	(Numero, Cliente_NRIDCivil)
	VALUES 
		('458 543 223', '124285589-2-XS2'),
		('178 346 789', '124285589-2-XS2'),
		('123 734 233', '342442149-8-DW1'),
		('233 238 445', '723009453-9-HG3'),
		('357 121 458', '335589029-1-RE0'),
		('890 450 233', '578923234-7-LP4'),
		('145 557 555', '578923234-7-LP4'),
        
        ('890 450 233', '327438434-2-MP3'),
		('145 557 555', '743845321-0-LP2'),
		('435 768 223', '324475465-1-CD3'),
		('231 987 342', '126637453-6-KL3'),
		('272 734 754', '344754322-4-HB2');
        
-- Povoamento da tabela "País"
INSERT INTO País
	(ID, Pais) -- Os acentos em atributos dão erro
	VALUES
	(1,'Portugal'),
    (2,'Suécia')  ,
    (3,'Suiça')   ,
    (4,'Alemanha'),
    (5,'França')  ;
-- Povoamento da tabela "Cidade"
INSERT INTO Cidade
	(ID, Cidade, País_ID)
    VALUES
    (1, 'Estocolmo', 2),
    (2, 'Lisboa'   , 1),
    (3, 'Porto'    , 1),
    (4, 'Berlim'   , 4),
    (5, 'Clermont' , 5),
    (6, 'Lausanne' , 3),
    (7, 'Genebra'  , 3);        
    
-- Povoamento da tabela "Morada"
INSERT INTO Morada
	(ID, Rua, Localidade, Cliente_NRIDCivil, Cidade_ID)
	VALUES
    (1,   'Grön Gata'          , 'Skrattar Du Förlorar Du', '124285589-2-XS2', 1),
    (2,   'Rua do Monte'       , 'Ferreiros'              , '342442149-8-DW1', 2),
    (3,   'Rua 88'             , 'Prado'                  , '723009453-9-HG3', 2),
    (4,   'Lugar de Baixo'     , 'Bairro Alto'            , '335589029-1-RE0', 2),
    (5,   'Loteamento Dourado' , 'Vila Fresca'            , '578923234-7-LP4', 3),
    (6,   'Lugar de Cima'      , 'La Louche'              , '327438434-2-MP3', 6),
    (7,   'Rua do Eiteiral'    , 'Minneola'               , '657485493-6-DI0', 5),
    (8,   'Rua Cavado'         , 'Carouge'                , '344754322-4-HB2', 7),
    (9,   'Lugar de Meio'      , 'Winter Garden'          , '324475465-1-CD3', 5),
    (10,  'Loteamento Linhares', 'Vila Fresca'            , '743845321-0-LP2', 3),
    (11,  'Feuer Strasse'	   , 'Checkpoint Charlie'     , '126637453-6-KL3', 4);

       
-- Povoamento da tabela "Aluguer"
INSERT INTO Aluguer
   (ID, Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis)
   VALUES
       (1, 1325, '2017/02/21', '2017/03/21', 800,  '124285589-2-XS2', '78NF3EV215'),
       (2, 1325, '2017/04/02', '2017/06/02', 1000, '342442149-8-DW1', '78NF3EV215'),
       (3, 2149, '2017/01/23', '2017/02/23', 300,  '335589029-1-RE0', '08W7XC224D'),
       (4, 3800, '2017/07/14', '2017/08/14', 1700, '578923234-7-LP4', '94ASXC22ER'),
	   (5, 2075, '2017/03/27', '2017/04/27', 1200, '124285589-2-XS2', '40RDF7E00R'),
       (6, 2911, '2017/10/21', '2017/12/21', 223 , '327438434-2-MP3', '51ZS9843CC'),
       (7, 3754, '2017/09/23', NULL 	   , NULL, '344754322-4-HB2', '94ASXC22ER');
       
-- Povoamento da tabela "Venda"
INSERT INTO Venda
   (ID, PrecoDeVenda, DataDeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis)
   VALUES
       (1, 27500, '2017/10/23', 5000,  '723009453-9-HG3', '78NF3EV215'),
       (2, 30250, '2017/11/20', NULL,  '578923234-7-LP4', '43SJ8232RD'),
       (3, 45000, '2017/07/14', 800,   '723009453-9-HG3', '51ZS9843CC'),
       (4, 47800, '2017/01/05', NULL,  '124285589-2-XS2', '98WE22CV4F'),
       (5, 41990, '2017/11/05', NULL,  '578923234-7-LP4', '08W7XC224D'),
	   (6, 31999, '2017/10/23', NULL,  '344754322-4-HB2', '70DS564723'),
       (7, 45000, '2017/11/20', 1000,  '342442149-8-DW1', '40RDF7E00R'),
	   (8, 23980, '2017/07/14', 800 ,  '335589029-1-RE0', '58VC213EDZ');


       
