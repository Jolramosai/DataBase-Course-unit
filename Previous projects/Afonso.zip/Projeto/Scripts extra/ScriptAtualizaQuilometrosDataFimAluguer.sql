/* Transacção inserção de cliente com a respetiva Compra  */
/* CALL trUpdateAluguerDeCliente("567348501-2-XK3","2017-02-01",1000,"65KJ9BVBSS"); */

DROP PROCEDURE IF EXISTS trUpdateAluguerDeCliente;
DELIMITER $$
CREATE PROCEDURE trUpdateAluguerDeCliente ( nrIDCivil varchar(45), fimDeAluguer DATE, quilometragemRealizada INT, nrChassis varchar(45))

BEGIN 
	
    START TRANSACTION;
    /*
		Existe um trigger que aumenta a quilometragem no carro

		UPDATE IGNORE Carro
		SET Quilometragem = Quilometragem + quilometragemRealizada
		WHERE Carro.NumeroChassis = nrChassis;			
	*/

		UPDATE IGNORE Aluguer
		SET Aluguer.FimDeAluguer = fimDeAluguer AND Aluguer.QuilometragemRealizada = quilometragemRealizada
		WHERE Aluguer.Carro_NumeroChassis = nrChassis AND Aluguer.Cliente_NRIDCivil = nrIDCivil;
		
END $$
DELIMITER ;