/* Transacção inserção de cliente com a respetiva Compra  */
/* CALL trInsereVendaDeClienteNovo("567348501-2-XK3","ALberto","Costa", "6378591" ,"1990/12/15", "5346-76-76", "jorge_4x4@hotmail.com", 23000,"2017-11-23", 20000, "58VC213EDZ"); */

DROP PROCEDURE IF EXISTS trInsereVendaDeClienteNovo;
DELIMITER $$
CREATE PROCEDURE trInsereVendaDeClienteNovo (
											nrIDCivil varchar(45), nomeProprio varchar(45), apelido varchar(45) , nib INT, datadeNascimento DATE, codigoPostal varchar(45), email varchar(45),
											precodeVenda INT, datadeVenda DATE, valordeAbate INT, nrChassis varchar(45)
											)
BEGIN 
    DECLARE ErroTransacaoClienteExistente  BOOL DEFAULT 0;
    DECLARE ErroTransacaoCarroExistente    BOOL DEFAULT 0;
    
    START TRANSACTION;
    
		Select count(*) INTO ErroTransacaoClienteExistente FROM Cliente WHERE Cliente.NRIDCivil = nrIDCivil;
        
        INSERT IGNORE INTO Cliente (NRIDCivil, NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, Email) 
			VALUES (nrIDCivil, nomeProprio , apelido, nib, datadeNascimento, codigoPostal, email);
		        
        Select count(*) INTO ErroTransacaoCarroExistente FROM Venda WHERE Venda.Carro_NumeroChassis = nrChassis;
		
		INSERT IGNORE INTO Venda (PrecodeVenda, DataDeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis) 
			VALUES (precodeVenda, datadeVenda , valordeAbate, nrIDCivil, nrChassis);
			 

        IF ErroTransacaoClienteExistente THEN
			ROLLBACK;
			SELECT 'Cliente já existente' AS ERRO;
		ELSEIF ErroTransacaoCarroExistente THEN
			ROLLBACK;
			SELECT 'Carro já Vendido' AS ERRO;
		ELSE
			-- ROLLBACK;
			COMMIT;
		END IF;
    
END$$
DELIMITER ;

/* Transacção inserção de cliente com a respetiva Compra  */
/* CALL trInsereAluguerDeClienteNovo("567348501-2-XK3","ALberto","Costa", "6378591" ,"1990/12/15", "5346-76-76", "jorge_4x4@hotmail.com", 23000,"2017-11-23", 20000, "58VC213EDZ"); */

DROP PROCEDURE IF EXISTS trInsereAluguerDeClienteNovo;
DELIMITER $$
CREATE PROCEDURE trInsereAluguerDeClienteNovo (
											nrIDCivil varchar(45), nomeProprio varchar(45), apelido varchar(45) , nib INT, datadeNascimento DATE, codigoPostal varchar(45), email varchar(45),
											mensalidade INT, inicioDeAluguer DATE, fimDeAluguer DATE, quilometragemRealizada INT, nrChassis varchar(45)
											)
BEGIN 
    DECLARE ErroTransacaoClienteExistente  BOOL DEFAULT 0;
    DECLARE ErroTransacaoCarroExistente    BOOL DEFAULT 0;
    
    START TRANSACTION;
    
		Select count(*) INTO ErroTransacaoClienteExistente FROM Cliente WHERE Cliente.NRIDCivil = nrIDCivil;
        
        INSERT IGNORE INTO Cliente (NRIDCivil, NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, Email) 
			VALUES (nrIDCivil, nomeProprio , apelido, nib, datadeNascimento, codigoPostal, email);
		        
        Select count(*) INTO ErroTransacaoCarroExistente FROM Venda WHERE Venda.Carro_NumeroChassis = nrChassis;
		
		INSERT IGNORE INTO Aluguer (Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis) 
				VALUES (mensalidade, inicioDeAluguer , fimDeAluguer ,quilometragemRealizada ,nrIDCivil, nrChassis);
			 

        IF ErroTransacaoClienteExistente THEN
			ROLLBACK;
			SELECT 'Cliente já existente' AS ERRO;
		ELSEIF ErroTransacaoCarroExistente THEN
			ROLLBACK;
			SELECT 'Carro já Alugado' AS ERRO;
		ELSE
			-- ROLLBACK;
			COMMIT;
		END IF;
    
END$$
DELIMITER ;