USE stand;

-- Povoamento da tabela "Carro"
INSERT INTO Carro
   (NumeroChassis, DataDeMatricula, Cor, Fabricante, Modelo, MSRP, CustoDoFornecedor, Combustivel, Cilindrada, Potencia, Quilometragem)
   VALUES
	 ('43SJ8232RD', '2017/03/05', 'Preto'  ,  'Seat'		,   'Leon'      ,   26500, 	23531, 	'Gasóleo' , 1968, 	150,	0)   ,
	 ('58VC213EDZ', '2017/01/22', 'Azul'   ,  'Volkswagen'  ,   'Polo GTI'  ,   23999, 	19823, 	'Gasolina', 1482, 	140,	0)   ,
	 ('78NF3EV215', '2016/12/10', 'Branco' ,  'Audi'		,   'A3'      	,	36544,	34637,	'Gasolina',	1398,	140,	1800),
	 ('21E1CXV333', '2017/04/10', 'Branco' ,  'Volkswagen'  ,   'Golf'      ,   19990, 	17410, 	'Gasóleo' , 1581, 	140,	0)   ,
	 ('40RDF7E00R', '2016/10/25', 'Cinza'  ,  'Audi'		,   'A4'        ,   41500, 	38423, 	'Gasolina', 1984, 	190,	1200),
	 ('51ZS9843CC', '2016/11/03', 'Cinza'  ,  'Volkswagen'  ,   'Golf R'    ,   39900, 	36543, 	'Gasolina', 1984, 	360,	0)   ,
	 ('08W7XC224D', '2017/01/17', 'Preto'  ,  'Audi'		,   'TT'		,   42990, 	39876, 	'Gasóleo', 1984, 	230,	300) ,
	 ('98WE22CV4F', '2017/02/19', 'Preto'  ,  'Audi'		,   'A5'		,   44990,	40404, 	'Gasolina', 1984, 	252,	0)   ,
	 ('983RVC78ML', '2017/04/15', 'Preto'  ,  'Seat'		,   'Leon Cupra', 	28999,  23456,  'Gasolina', 1984, 	300,	1700),
     ('70DS564723', '2016/03/05', 'Preto'  ,  'BMW'         ,	'Serie 1' 	,	34287,	30876,	'Gasóleo' ,	1968,	130,	7679),
     ('80FE238954', '2016/01/22', 'Azul'   ,  'Renault'     ,	'Laguna'  	,	27865,	23788,	'Gasóleo' ,	1587,	130,	3987),
     ('85TGJGKF76', '2016/12/10', 'Verde'  ,  'Audi'        ,	'A3'      	,	36544,	34637,	'Gasolina',	1398,	140,	1800),
     ('87UYCNCN98', '2016/04/10', 'Branco' ,  'Volkswagen'  ,	'Golf'    	,	19990, 	17410, 	'Gasóleo' , 1581, 	140,	0)	 ,
     ('23IUBHDS12', '2017/10/25', 'Cinza'  ,  'Renault'     ,	'Clio'    	,	24534,	18423,	'Gasolina',	1587,	110,	1200),
     ('65KJ9BVBSS', '2014/11/03', 'Cinza'  ,  'Volkswagen'  ,	'Golf R'    ,	39900, 	36543, 	'Gasolina', 1984, 	360,	1002),
     ('94ASXC22ER', '2017/01/17', 'Branco' ,  'Renault'     ,	'Megane'    ,	42990,	39876,	'Gasolina',	1587,	150,	300) ,
     ('23YTEDEFTR', '2016/02/19', 'Amarelo',  'Audi'        ,	'A5'      	,	44213,	40404,	'Gasóleo' ,	1984,	252,	653) ,
     ('14OPMKLGUJ', '2016/04/15', 'Preto'  ,  'Fiat'        ,	'500'     	,	23657,	20476,	'Gasolina',	1487,	110,	1700),
	 ('21ER8232RD', '2016/06/30', 'Preto'  ,  'Alfa Romeo'  ,   'Mito'      ,   16700, 	15000, 	'Gasolina', 1598, 	110,	1298),
	 ('67YH213EDZ', '2017/09/13', 'Azul'   ,  'Volkswagen'  ,   'Polo GTI'  ,   23999, 	19823, 	'Gasolina', 1482, 	140,	0)   ,
	 ('09IK3EV215', '2015/12/10', 'Verde'  ,  'Audi'		,   'A3'      	,	36544,	34637,	'Gasolina',	1398,	140,	1800),
	 ('87OLCXV333', '2017/10/23', 'Branco' ,  'Volkswagen'  ,   'Golf'      ,   19990, 	17410, 	'Gasóleo' , 1581, 	140,	0)   ,
	 ('65FVF7E76R', '2016/10/25', 'Cinza'  ,  'Renault'     ,	'Clio'    	,	24534,	18423,	'Gasolina',	1587,	110,	1198),
	 ('78SX9843CC', '2016/03/03', 'Cinza'  ,  'Fiat'        ,	'500'     	,	23657,	20476,	'Gasolina',	1487,	110,	200) ,
	 ('16AZXC224D', '2016/08/17', 'Preto'  ,  'Audi'		,   'TT'		,   42990, 	39876, 	'Gasóleo', 1984, 	230,	300) ,
	 ('75DC352V4F', '2017/10/31', 'Verde'  ,  'Alfa Romeo'  ,   'Mito'      ,   16700, 	15000, 	'Gasolina', 1598, 	110,	0)   ,
	 ('45GBVC78ML', '2017/04/15', 'Preto'  ,  'Seat'		,   'Leon Cupra', 	28999,  23456,  'Gasolina', 1984, 	300,	1700),
     ('32TG532723', '2016/12/05', 'Verde'  ,  'BMW'         ,	'Serie 1' 	,	34287,	30876,	'Gasóleo' ,	1968,	130,	7679),
     ('44IK238954', '2016/12/22', 'Azul'   ,  'Renault'     ,	'Laguna'  	,	27865,	23788,	'Gasóleo' ,	1587,	130,	3987),
     ('89TGJGKF76', '2017/11/10', 'Verde'  ,  'Audi'        ,	'A3'      	,	36544,	34637,	'Gasolina',	1398,	140,	798) ,
     ('04UYCFRN98', '2016/08/12', 'Verde'  ,  'Volkswagen'  ,	'Golf'    	,	19990, 	17410, 	'Gasóleo' , 1581, 	140,	654) ,
     ('23IUB32S12', '2016/10/25', 'Cinza'  ,  'Renault'     ,	'Clio'    	,	24534,	18423,	'Gasolina',	1587,	110,	0)   ,
     ('54UJ933BSS', '2016/07/06', 'Cinza'  ,  'Alfa Romeo'  ,   'Mito'      ,   16700, 	15000, 	'Gasolina', 1598, 	110,	1002),
     ('76WOXC22ER', '2016/01/17', 'Branco' ,  'Renault'     ,	'Megane'    ,	42990,	39876,	'Gasolina',	1587,	150,	300) ,
     ('10PLEDEFTR', '2016/05/19', 'Amarelo',  'Audi'        ,	'A5'      	,	44213,	40404,	'Gasóleo' ,	1984,	252,	653) ,
     ('97IKMK21UJ', '2017/04/15', 'Verde'  ,  'Fiat'        ,	'500'     	,	23657,	20476,	'Gasolina',	1487,	110,	1700);
       
-- Povoamento da tabela "Cliente"
INSERT INTO Cliente
   (NRIDCivil , NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, email)
   VALUES
     ('124285589-2-XS2', 'Zlatan'  ,  'Ibra'     ,   1234923, '1981/11/03', '9999-99-99 Zlatanpost', 'zlatan@ibra.com')  ,
	 ('342442149-8-DW1', 'Rui'     ,  'Vitória'  ,   4950312, '1940/03/10', '1450-43-21 Champ'	   , 'rv@gmail.com')     ,
     ('723009453-9-HG3', 'Jorge'   ,  'Jesus'    ,   2334454, '1954/07/24', '5543-78-90 Bola'	   , 'jj@gorila.com')    ,
     ('335589029-1-RE0', 'Bruno'   ,  'Carvalho' ,   1894923, '1972/02/08', '5543-78-59 Bolinha'   , 'br@sportingcp.com'),
     ('578923234-7-LP4', 'Pinto'   ,  'Costa'    ,   7845920, '1937/12/28', '7439-33-33 Penta'	   , 'pc@fcporto.com')   ,
     ('327438434-2-XS2', 'Nando'   ,  'Vale'     ,   1234923, '1981/11/03', '9999-99-99 Zlatanpost', 'zlatan@ibra.com')  ,
	 ('657485493-8-DW1', 'Joel'    ,  'Sousa'    ,   4950312, '1940/03/10', '1450-43-21 Gronha'	   , 'rv@gmail.com')     ,
     ('344754322-9-HG3', 'Diogo'   ,  'Teixeira' ,   2334454, '1954/07/24', '5543-78-90 Lugar'	   , 'jj@gorila.com')    ,
     ('324475465-1-RE0', 'Celso'   ,  'Carvalho' ,   1894923, '1972/02/08', '5543-78-59 Urge'	   , 'br@sportingcp.com'),
     ('743845321-7-LP4', 'Armando' ,  'Francisco',   7845920, '1937/12/28', '7439-33-33 Etru'	   , 'pc@fcporto.com')   ,
     ('465738923-4-RE7', 'Carlos'  ,  'Santos'   ,   3478122, '1984/11/12', '4805-49-99 Donim'     , 'rolha@hotmail.com'),
	 ('457438294-6-TR3', 'Artur'   ,  'Barbosa'  ,   3267342, '1930/03/30', '2450-33-21 Briteiros' , 'cs@gmail.com')     ,
     ('345643789-5-YU0', 'Jorge'   ,  'Cardoso'  ,   9238945, '1978/07/22', '3543-38-90 Serzedelo' , 'ab@sapo.com')      ,
     ('632623829-2-UR1', 'Fernando',  'Madureira',   1234432, '1992/02/01', '1543-98-59 Uiyt'	   , 'jc@hotmail.com')   ,
     ('123737445-1-OI8', 'Fatima'  ,  'Moreira'  ,   9281732, '1987/12/09', '2439-23-33 Ore'	   , 'fc@gmail.com')     ,
     ('564382321-2-AS6', 'José'    ,  'Augusto'  ,   2133453, '1990/11/29', '3999-19-99 Dramsic'   , 'fm@clip.com')      ,
	 ('356786988-7-XC2', 'Armindo' ,  'Soares'   ,   1234534, '1986/03/21', '2450-53-21 Koilert'   , 'ac@gmail.com')     ,
     ('324567897-9-GF3', 'Ana'     ,  'Costa'    ,   2132047, '1947/07/14', '6543-88-90 Champli'   , 'anac@hotmail.com') ,
     ('453401232-3-UI1', 'Aurea'   ,  'Lima'     ,   3246721, '1964/02/12', '8543-18-59 Coirt'	   , 'er@vitoriasc.com') ,
     ('126637453-6-KL3', 'João'    ,  'Ferreira' ,   3767483, '1967/12/11', '3439-73-33 Serew'	   , 'pc@gmail.com')     ;

-- Povoamento da tabela "Telefone"
INSERT INTO Telefone
	(Numero, Cliente_NRIDCivil)
	VALUES 
	  ('458 543 223', '124285589-2-XS2'),
	  ('178 346 789', '327438434-2-XS2'),
	  ('123 734 233', '342442149-8-DW1'),
	  ('233 238 445', '723009453-9-HG3'),
	  ('357 121 458', '335589029-1-RE0'),
	  ('890 450 233', '657485493-8-DW1'),
	  ('145 557 555', '578923234-7-LP4'),
	  ('435 768 223', '465738923-4-RE7'),
	  ('231 987 342', '457438294-6-TR3'),
	  ('272 734 754', '345643789-5-YU0'),
	  ('823 362 233', '632623829-2-UR1'),
	  ('023 988 654', '123737445-1-OI8'),
	  ('672 231 832', '564382321-2-AS6'),
	  ('322 743 176', '356786988-7-XC2');
        
-- Povoamento da tabela "País"
INSERT INTO País
	(ID, Pais) -- Os acentos em atributos dão erro
	VALUES
	(1,'Portugal'),
    (2,'Suécia')  ,
    (3,'Espanha') ,
    (4,'Suiça')   ,
    (5,'Alemanha'),
    (6,'França')  ;
        
-- Povoamento da tabela "Morada"
INSERT INTO Cidade
	(ID, Cidade, País_ID)
    VALUES
    (1,  'Estocolmo', 2),
    (2,  'Lisboa'   , 1),
    (3,  'Porto'    , 1),
    (4,  'Berlim'   , 5),
    (5,  'Zurique'  , 4),
    (6,  'Madrid'   , 3),  
    (7,  'Paris'    , 6),
    (8,  'Frankfurt', 5),
    (9,  'Guimarães', 1),
    (10, 'Clermont' , 6),
    (11, 'Lausanne' , 4),
    (12, 'Genebra'  , 4),
    (13, 'Gijon'    , 3);     
    
-- Povoamento da tabela "Morada"
INSERT INTO Morada
	(ID, Rua, Localidade, Cliente_NRIDCivil, Cidade_ID)
	VALUES
    (1,   'Grön Gata'          , 'Skrattar Du Förlorar Du', '124285589-2-XS2', 1) ,
    (2,   'Rua do Monte'       , 'Ferreiros'              , '342442149-8-DW1', 2) ,
    (3,   'Rua 88'             , 'Prado'                  , '723009453-9-HG3', 2) ,
    (4,   'Lugar de Baixo'     , 'Bairro Alto'            , '335589029-1-RE0', 2) ,
    (5,   'Loteamento Dourado' , 'Vila Fresca'            , '578923234-7-LP4', 3) ,
    (6,   'Lugar de Cima'      , 'La Louche'              , '657485493-8-DW1', 11),
    (7,   'Rua do Eiteiral'    , 'Minneola'               , '327438434-2-XS2', 10),
    (8,   'Rua Cavado'         , 'Carouge'                , '344754322-9-HG3', 12),
    (9,   'Lugar de Meio'      , 'Winter Garden'          , '457438294-6-TR3', 10),
    (10,  'Loteamento Linhares', 'Vila Fresca'            , '324475465-1-RE0', 3) ,
    (11,  'Lugar da Igreja'    , 'Mitte'                  , '743845321-7-LP4', 4) ,
    (12,  'Rua da Ponte'       , 'Clichy'                 , '465738923-4-RE7', 7) ,
    (13,  'Rua da Condeixa'    , 'Vidy'                   , '345643789-5-YU0', 11),
    (14,  'Lugar da UM'        , 'Donim'                  , '632623829-2-UR1', 9) ,
    (15,  'Loteamento Carvalho', 'Arrabida'               , '123737445-1-OI8', 3) ,
    (16,  'Rua da Junta'       , 'Nacka'                  , '564382321-2-AS6', 1) ,
    (17,  'Rua do Fonte'       , 'Vincennes'              , '356786988-7-XC2', 7) ,
    (18,  'Rua do Aramando'    , 'Meyrin'                 , '324567897-9-GF3', 12),
    (19,  'Lugar de Cavalo'    , 'Caldas das Taipas'      , '453401232-3-UI1', 9) ,
    (20,  'Loteamento Cruzado' , 'Gatow'                  , '126637453-6-KL3', 4) ;
                

       
INSERT INTO Aluguer
   (ID, Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis)
   VALUES
     (1,  1325, '2017/02/21', '2017/03/21', 800 ,  '124285589-2-XS2', '43SJ8232RD'),
     (2,  1325, '2017/04/02', '2017/05/02', 1000,  '342442149-8-DW1', '58VC213EDZ'),
     (3,  2149, '2017/01/23', '2017/03/23', 300 ,  '335589029-1-RE0', '78NF3EV215'),
     (4,  1449, '2017/07/14', '2017/08/14', 1700,  '578923234-7-LP4', '21E1CXV333'),
	 (5,  2075, '2017/03/27', '2017/04/27', 1200,  '124285589-2-XS2', '40RDF7E00R'),
	 (6,  2911, '2017/10/21', '2017/12/21', 223 ,  '327438434-2-XS2', '51ZS9843CC'),
     (7,  1354, '2017/11/02', '2017/12/02', 3546,  '657485493-8-DW1', '08W7XC224D'),
     (8,  3754, '2017/09/23', '2017/11/23', 3263,  '344754322-9-HG3', '98WE22CV4F'),
     (9,  1200, '2017/06/14', '2017/08/14', 2134,  '324475465-1-RE0', '983RVC78ML'),
	 (10, 1329, '2017/03/27', '2017/04/27', 1564,  '743845321-7-LP4', '70DS564723'),
	 (11, 1987, '2017/06/21', '2017/07/21', 1457,  '465738923-4-RE7', '80FE238954'),
     (12, 2131, '2017/08/02', '2017/09/02', 6832,  '457438294-6-TR3', '85TGJGKF76'),
     (13, 2001, '2017/01/23', '2017/03/23', 1462,  '345643789-5-YU0', '67YH213EDZ'),
     (14, 2342, '2017/01/14', '2017/03/14', 2341,  '632623829-2-UR1', '16AZXC224D'),
	 (15, 1786, '2017/10/27', '2017/11/27', 2464,  '123737445-1-OI8', '32TG532723'),
	 (16, 1376, '2017/07/21', '2017/08/21', 1246,  '564382321-2-AS6', '54UJ933BSS'),
     (17, 1243, '2017/04/02', '2017/05/02', 1001,  '356786988-7-XC2', '78NF3EV215'),
     (18, 1457, '2017/10/23', '2017/11/23', 2344,  '324567897-9-GF3', '09IK3EV215'),
     (19, 2837, '2017/03/14', '2017/05/14', 1565,  '453401232-3-UI1', '76WOXC22ER'),
	 (20, 1598, '2017/04/27', '2017/05/27', 1200,  '126637453-6-KL3', '65FVF7E76R');
       
-- Povoamento da tabela "Venda"
INSERT INTO Venda
   (ID, PrecoDeVenda, DataDeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis)
   VALUES
     (1,  27500, '2017/10/23', 5000,  '723009453-9-HG3', '97IKMK21UJ'),
     (2,  30250, '2017/11/20', NULL,  '578923234-7-LP4', '10PLEDEFTR'),
     (3,  45000, '2017/07/14', 800 ,  '743845321-7-LP4', '23IUB32S12'),
     (4,  47800, '2017/01/05', NULL,  '124285589-2-XS2', '04UYCFRN98'),
     (5,  41990, '2017/11/05', NULL,  '465738923-4-RE7', '89TGJGKF76'),
     (6,  30981, '2017/10/23', 5000,  '345643789-5-YU0', '44IK238954'),
     (7,  23665, '2017/11/20', 1000,  '632623829-2-UR1', '45GBVC78ML'),
     (8,  26642, '2017/07/14', 800 ,  '123737445-1-OI8', '75DC352V4F'),
     (9,  47830, '2017/01/05', 750 ,  '564382321-2-AS6', '78SX9843CC'),
     (10, 13432, '2017/11/05', 430 ,  '356786988-7-XC2', '87UYCNCN98'),
     (11, 23980, '2017/07/14', 800 ,  '324567897-9-GF3', '21ER8232RD'),
     (12, 19087, '2017/01/05', 1000,  '453401232-3-UI1', '14OPMKLGUJ'),
     (13, 23617, '2017/11/05', NULL,  '126637453-6-KL3', '87OLCXV333');
     (14, 41500, '2017/11/02', NULL, , '40RDF7E00R'
