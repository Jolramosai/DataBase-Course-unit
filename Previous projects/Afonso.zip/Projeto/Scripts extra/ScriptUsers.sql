/* Criado admin e usuário */
/* Nome - funcionario	pwd - admin
   Nome - cliente		pwd - user */
   
CREATE USER 'funcionario'@'localhost' IDENTIFIED BY 'admin';
GRANT ALL PRIVILEGES ON stand.* TO 'admin'@'localhost';
FLUSH PRIVILEGES;

CREATE USER 'cliente'@'localhost' IDENTIFIED BY 'user';
GRANT UPDATE, SELECT ON stand.* TO 'user'@'localhost';
FLUSH PRIVILEGES;

/*Para alterar privilégios*/
/*REVOKE UPDATE ON stand.* FROM ‘user’@‘localhost’;*/

/*Para apagar qualquer utilizador*/
/*DROP USER 'user'@'localhost';*/
/*DROP USER 'administrador'@'localhost';*/