/* Transacção inserção de cliente com a respetiva Compra ou Aluguer  */
/* CALL trCliente("567348501-2-XK3","ALberto","Costa", "6378591" ,"1990/12/15", "5346-76-76", "jorge_4x4@hotmail.com", 1, 0,23000,"2017-11-23", NULL , 20000, "58VC213EDZ"); */

DROP PROCEDURE IF EXISTS trCliente;
DELIMITER $$
CREATE PROCEDURE trCliente (
							VAnrIDCivil varchar(45), nomeProprio varchar(45), apelido varchar(45) , nib INT, datadeNascimento DATE, codigoPostal varchar(45), email varchar(45),
                            eVenda INT, eAluguer INT,
							VprecodeVenda_Amensalidade INT, VdatadeVenda_AinicioAluguer DATE, AfimAluguer DATE, VvalordeAbate_AquilometragemRealizada INT, VAnrChassis varchar(45)
                            )
BEGIN 
    DECLARE ErroTransacaoClienteExistente  BOOL DEFAULT 0;
 
    START TRANSACTION;
    
		Select count(*) INTO ErroTransacaoClienteExistente FROM Cliente WHERE Cliente.NRIDCivil = nrIDCivil;
        
		INSERT IGNORE INTO Cliente (NRIDCivil, NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, Email) 
			VALUES (VAnrIDCivil, nomeProprio , apelido, nib, datadeNascimento, codigoPostal, email);
		
        IF eVenda = 1 THEN
        
			INSERT IGNORE INTO Venda (PrecodeVenda, DataDeVenda, ValorDeAbate, Cliente_NRIDCivil, Carro_NumeroChassis) 
				VALUES (VprecodeVenda_Amensalidade, VdatadeVenda_AinicioAluguer , VvalordeAbate_AquilometragemRealizada, VAnrIDCivil, VAnrChassis);
			 
        END IF;
        
        IF eAluguer = 1 THEN
			
            INSERT IGNORE INTO Aluguer (Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis) 
				VALUES (VprecodeVenda_Amensalidade, VdatadeVenda_AinicioAluguer, AfimAluguer, VvalordeAbate_AquilometragemRealizada, VAnrIDCivil, VAnrChassis);
	
		END IF;
	
		IF eVenda = 0 AND eAluguer = 0 THEN
			ROLLBACK;
            SELECT 'Insira qual a opção do Cliente ( Compra ou Aluguer )' AS ERRO;
		ELSE
			COMMIT;
		END IF;
        
        IF ErroTransacaoClienteExistente THEN
			ROLLBACK;
			SELECT 'Cliente já existente' AS ERRO;
		ELSE
			-- ROLLBACK;
			COMMIT;
		END IF;
    
END$$
DELIMITER ;