/* Transacção inserção de cliente com a respetiva Compra  */
/* CALL trInsereAluguerDeClienteNovo("567348501-2-XK3","Alberto","Costa", "6378591" ,"1990-12-15", "5346-76-76", "jorge_4x4@hotmail.com", 23000,"2017-01-01",NULL,NULL, "65KJ9BVBSS") */
DROP PROCEDURE IF EXISTS trInsereAluguerDeClienteNovo;
DELIMITER $$
CREATE PROCEDURE trInsereAluguerDeClienteNovo (
											nrIDCivil varchar(45), nomeProprio varchar(45), apelido varchar(45) , nib INT, datadeNascimento DATE, codigoPostal varchar(45), email varchar(45),
											mensalidade INT, inicioDeAluguer DATE, fimDeAluguer DATE, quilometragemRealizada INT, nrChassis varchar(45)
											)
BEGIN 
    DECLARE ErroTransacaoClienteExistente  BOOL DEFAULT 0;
    DECLARE ErroTransacaoCarroExistente    BOOL DEFAULT 0;
    
    START TRANSACTION;
    
		Select count(*) INTO ErroTransacaoClienteExistente FROM Cliente WHERE Cliente.NRIDCivil = nrIDCivil;
        
        INSERT IGNORE INTO Cliente (NRIDCivil, NomeProprio, Apelido, NIB, DataDeNascimento, CodigoPostal, Email) 
			VALUES (nrIDCivil, nomeProprio , apelido, nib, datadeNascimento, codigoPostal, email);
		        
        Select count(*) INTO ErroTransacaoCarroExistente FROM Aluguer WHERE Aluguer.Carro_NumeroChassis = nrChassis;
		
		INSERT IGNORE INTO Aluguer (Mensalidade, InicioDeAluguer, FimDeAluguer, QuilometragemRealizada, Cliente_NRIDCivil, Carro_NumeroChassis) 
				VALUES (mensalidade, inicioDeAluguer , fimDeAluguer ,quilometragemRealizada ,nrIDCivil, nrChassis);
			 

        IF ErroTransacaoClienteExistente THEN
			ROLLBACK;
			SELECT 'ERRO Cliente' AS ERRO;
		
        ELSEIF ErroTransacaoCarroExistente THEN
			ROLLBACK;
			SELECT 'ERRO CARRO' AS ERRO;
		ELSE
			-- ROLLBACK;
			COMMIT;
		END IF;
    
END$$
DELIMITER ;