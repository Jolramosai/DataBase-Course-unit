-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema stand
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema stand
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `stand` DEFAULT CHARACTER SET utf8 ;
USE `stand` ;

-- -----------------------------------------------------
-- Table `stand`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Cliente` (
  `NRIDCivil` VARCHAR(45) NOT NULL,
  `NomeProprio` VARCHAR(45) NOT NULL,
  `Apelido` VARCHAR(45) NOT NULL,
  `NIB` INT NOT NULL,
  `DataDeNascimento` DATE NOT NULL,
  `CodigoPostal` VARCHAR(45) NOT NULL,
  `Email` VARCHAR(45) NULL,
  PRIMARY KEY (`NRIDCivil`),
  UNIQUE INDEX `NRIDCivil_UNIQUE` (`NRIDCivil` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Carro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Carro` (
  `NumeroChassis` VARCHAR(45) NOT NULL,
  `DataDeMatricula` DATE NOT NULL,
  `Cor` VARCHAR(45) NOT NULL,
  `Fabricante` VARCHAR(45) NOT NULL,
  `Modelo` VARCHAR(45) NOT NULL,
  `MSRP` INT NOT NULL,
  `CustoDoFornecedor` INT NOT NULL,
  `Combustivel` VARCHAR(45) NOT NULL,
  `Cilindrada` INT NOT NULL,
  `Potencia` INT NOT NULL,
  `Quilometragem` INT NOT NULL,
  PRIMARY KEY (`NumeroChassis`),
  UNIQUE INDEX `NumeroChassis_UNIQUE` (`NumeroChassis` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Venda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Venda` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `PrecoDeVenda` INT NOT NULL,
  `DataDeVenda` DATE NOT NULL,
  `ValorDeAbate` INT NULL,
  `Cliente_NRIDCivil` VARCHAR(45) NOT NULL,
  `Carro_NumeroChassis` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ID`, `Cliente_NRIDCivil`, `Carro_NumeroChassis`),
  INDEX `fk_Venda_Cliente1_idx` (`Cliente_NRIDCivil` ASC),
  INDEX `fk_Venda_Carro1_idx` (`Carro_NumeroChassis` ASC),
  UNIQUE INDEX `ID_UNIQUE` (`ID` ASC),
  CONSTRAINT `fk_Venda_Cliente1`
    FOREIGN KEY (`Cliente_NRIDCivil`)
    REFERENCES `stand`.`Cliente` (`NRIDCivil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Venda_Carro1`
    FOREIGN KEY (`Carro_NumeroChassis`)
    REFERENCES `stand`.`Carro` (`NumeroChassis`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Aluguer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Aluguer` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `Mensalidade` INT NOT NULL,
  `InicioDeAluguer` DATE NOT NULL,
  `FimDeAluguer` DATE NULL,
  `QuilometragemRealizada` INT NULL,
  `Cliente_NRIDCivil` VARCHAR(45) NOT NULL,
  `Carro_NumeroChassis` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ID`, `Cliente_NRIDCivil`, `Carro_NumeroChassis`),
  INDEX `fk_Aluguer_Cliente1_idx` (`Cliente_NRIDCivil` ASC),
  INDEX `fk_Aluguer_Carro1_idx` (`Carro_NumeroChassis` ASC),
  UNIQUE INDEX `ID_UNIQUE` (`ID` ASC),
  CONSTRAINT `fk_Aluguer_Cliente1`
    FOREIGN KEY (`Cliente_NRIDCivil`)
    REFERENCES `stand`.`Cliente` (`NRIDCivil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Aluguer_Carro1`
    FOREIGN KEY (`Carro_NumeroChassis`)
    REFERENCES `stand`.`Carro` (`NumeroChassis`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Telefone`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Telefone` (
  `Numero` VARCHAR(45) NOT NULL,
  `Cliente_NRIDCivil` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Cliente_NRIDCivil`, `Numero`),
  INDEX `fk_Telefone_Cliente1_idx` (`Cliente_NRIDCivil` ASC),
  CONSTRAINT `fk_Telefone_Cliente1`
    FOREIGN KEY (`Cliente_NRIDCivil`)
    REFERENCES `stand`.`Cliente` (`NRIDCivil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`País`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`País` (
  `ID` INT NOT NULL,
  `Pais` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Cidade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Cidade` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `Cidade` VARCHAR(45) NOT NULL,
  `País_ID` INT NOT NULL,
  PRIMARY KEY (`ID`, `País_ID`),
  INDEX `fk_Cidade_País1_idx` (`País_ID` ASC),
  CONSTRAINT `fk_Cidade_País1`
    FOREIGN KEY (`País_ID`)
    REFERENCES `stand`.`País` (`ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `stand`.`Morada`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stand`.`Morada` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `Rua` VARCHAR(45) NOT NULL,
  `Localidade` VARCHAR(45) NOT NULL,
  `Cliente_NRIDCivil` VARCHAR(45) NOT NULL,
  `Cidade_ID` INT NOT NULL,
  PRIMARY KEY (`ID`, `Cliente_NRIDCivil`, `Cidade_ID`),
  INDEX `fk_Morada_Cliente1_idx` (`Cliente_NRIDCivil` ASC),
  INDEX `fk_Morada_Cidade1_idx` (`Cidade_ID` ASC),
  CONSTRAINT `fk_Morada_Cliente1`
    FOREIGN KEY (`Cliente_NRIDCivil`)
    REFERENCES `stand`.`Cliente` (`NRIDCivil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Morada_Cidade1`
    FOREIGN KEY (`Cidade_ID`)
    REFERENCES `stand`.`Cidade` (`ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
