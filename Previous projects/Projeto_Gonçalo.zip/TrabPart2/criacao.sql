-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Aluno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Aluno` (
  `Nome` VARCHAR(45) NOT NULL,
  `Numero` INT NOT NULL,
  `Morada` VARCHAR(45) NOT NULL,
  `Encarregado` VARCHAR(45) NOT NULL,
  `Data_Nasc` DATE NOT NULL,
  `Email` VARCHAR(45) NULL,
  PRIMARY KEY (`Numero`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Professor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Professor` (
  `Numero` INT NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `Data_Nasc` DATE NOT NULL,
  `Morada` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NULL,
  PRIMARY KEY (`Numero`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Turma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Turma` (
  `idTurma` INT NOT NULL,
  `Numero` INT NOT NULL,
  `Sala` INT NOT NULL,
  `Ano` INT NOT NULL,
  `Professor_Numero` INT NOT NULL,
  PRIMARY KEY (`idTurma`),
  INDEX `fk_Turma_Professor1_idx` (`Professor_Numero` ASC),
  CONSTRAINT `fk_Turma_Professor1`
    FOREIGN KEY (`Professor_Numero`)
    REFERENCES `mydb`.`Professor` (`Numero`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Disciplina` (
  `idDisc` INT NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `Programa` VARCHAR(200) NOT NULL,
  `cargaHoraria` INT NOT NULL,
  PRIMARY KEY (`idDisc`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Inscricao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Inscricao` (
  `idInscricao` INT NOT NULL,
  `AnoLetivo` VARCHAR(45) NOT NULL,
  `Aluno_Numero` INT NOT NULL,
  `Turma_idTurma` INT NOT NULL,
  PRIMARY KEY (`idInscricao`),
  INDEX `fk_Inscricao_Aluno1_idx` (`Aluno_Numero` ASC),
  INDEX `fk_Inscricao_Turma1_idx` (`Turma_idTurma` ASC),
  CONSTRAINT `fk_Inscricao_Aluno1`
    FOREIGN KEY (`Aluno_Numero`)
    REFERENCES `mydb`.`Aluno` (`Numero`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Inscricao_Turma1`
    FOREIGN KEY (`Turma_idTurma`)
    REFERENCES `mydb`.`Turma` (`idTurma`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Avaliacao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Avaliacao` (
  `idAvaliacao` INT NOT NULL,
  `Data` DATE NOT NULL,
  `Nota` INT NOT NULL,
  `Tipo` VARCHAR(45) NOT NULL,
  `peso` INT NOT NULL,
  `Tema` VARCHAR(45) NOT NULL,
  `Inscricao_idInscricao` INT NOT NULL,
  `Disciplina_idDisc` INT NOT NULL,
  PRIMARY KEY (`idAvaliacao`),
  INDEX `fk_Avaliacao_Inscricao1_idx` (`Inscricao_idInscricao` ASC),
  INDEX `fk_Avaliacao_Disciplina1_idx` (`Disciplina_idDisc` ASC),
  CONSTRAINT `fk_Avaliacao_Inscricao1`
    FOREIGN KEY (`Inscricao_idInscricao`)
    REFERENCES `mydb`.`Inscricao` (`idInscricao`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Avaliacao_Disciplina1`
    FOREIGN KEY (`Disciplina_idDisc`)
    REFERENCES `mydb`.`Disciplina` (`idDisc`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`telefoneAluno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`telefoneAluno` (
  `idtelefoneAluno` INT NOT NULL,
  `Telefone` INT NOT NULL,
  `Aluno_Numero` INT NOT NULL,
  PRIMARY KEY (`idtelefoneAluno`),
  INDEX `fk_telefoneAluno_Aluno_idx` (`Aluno_Numero` ASC),
  CONSTRAINT `fk_telefoneAluno_Aluno`
    FOREIGN KEY (`Aluno_Numero`)
    REFERENCES `mydb`.`Aluno` (`Numero`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`telefoneProf`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`telefoneProf` (
  `idtelefoneProf` INT NOT NULL,
  `Telefone` INT NOT NULL,
  `Professor_Numero` INT NOT NULL,
  PRIMARY KEY (`idtelefoneProf`),
  INDEX `fk_telefoneProf_Professor1_idx` (`Professor_Numero` ASC),
  CONSTRAINT `fk_telefoneProf_Professor1`
    FOREIGN KEY (`Professor_Numero`)
    REFERENCES `mydb`.`Professor` (`Numero`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Turma_has_Disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Turma_has_Disciplina` (
  `Turma_idTurma` INT NOT NULL,
  `Disciplina_idDisc` INT NOT NULL,
  PRIMARY KEY (`Turma_idTurma`, `Disciplina_idDisc`),
  INDEX `fk_Turma_has_Disciplina_Disciplina1_idx` (`Disciplina_idDisc` ASC),
  INDEX `fk_Turma_has_Disciplina_Turma1_idx` (`Turma_idTurma` ASC),
  CONSTRAINT `fk_Turma_has_Disciplina_Turma1`
    FOREIGN KEY (`Turma_idTurma`)
    REFERENCES `mydb`.`Turma` (`idTurma`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Turma_has_Disciplina_Disciplina1`
    FOREIGN KEY (`Disciplina_idDisc`)
    REFERENCES `mydb`.`Disciplina` (`idDisc`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
