USE mydb;aluno

INSERT INTO Aluno
	(Nome, Numero, Morada, Encarregado, Data_Nasc, Email)
	VALUES 
		('Goncalo Moreira', 118, 'Rua de Vasconcelos, Braga', 'Paulo Moreira', '2008-04-13', 'pme13@hotmail.com'),
		('Vania Teixeira', 119, 'Rua dos Carvalhos, Braga', 'Joana Teixeira', '2008-07-23', 'jte23@gmail.com'),
        ('Rui Carvalho', 120, 'Avenida D.Henrique, Braga', 'Mario Carvalho', '2008-02-02', 'mce02@hotmail.com'),
        ('Joao Figueira', 121, 'Rua da Fonte Nova, Braga', 'Paulo Figueira', '2008-08-29', 'pfe29@sapo.pt'),
        ('Maria Fernandes', 122, 'Rua D.Dinis, Braga', 'Otavia Fernandes', '2008-05-10', 'ofe10@hotmail.com'),
        ('Catarina Cardoso', 123, 'Rua Padre Rogerio Santos, Braga', 'Conceicao Cardoso', '2008-10-22', 'cce22@gmail.com'),
		('Joao Cunha', 124, 'Rua de Barros, Braga', 'Maria Cunha', '2009-09-01', 'mce01@hotmail.com'),
		('Miguel Esteves', 125, 'Rua Sa da Bandeira, Braga', 'Fernando Esteves', '2009-01-05', 'fee05@gmail.com'),
        ('Ana Santos', 126, 'Rua da Irmandade, Braga', 'Rui Santos', '2009-04-03', 'rse03@hotmail.com'),
        ('Catarina Moreira', 127, 'Avenida dos Orfaos, Braga', 'Paulo Moreira', '2009-12-08', 'pme08@hotmail.com'),
        ('Pedro Mota', 128, 'Rua Doctor Madruga, Braga', 'Inacio Mota', '2009-02-20', 'ice20@hotmail.com'),
        ('Joao Magalhaes', 129, 'Rua da Santa Fe, Braga', 'Pedro Magalhaes', '2009-07-22', 'pme22@hotmail.com'),
        ('Rita Meireles', 130, 'Rua dos Capelinhos, Braga', 'Mariana Meireles', '2010-11-19', 'mme19@hotmail.com'),
        ('Jorge Mendonca', 131, 'Avenida S.Jorge, Braga', 'Rogerio Mendonca', '2010-06-25', 'rme25@gmail.com'),
		('Francisco Guedes', 132, 'Rua Bispo Manuel, Braga', 'Paulo Guedes', '2010-04-23', 'pge23@sapo.pt'),
        ('Elisa Pessoa', 133, 'Rua Innocentius III, Braga', 'Angelina Pessoa', '2010-09-16', 'ape16@hotmail.com'),
		('Rubem Alves', 134, 'Rua das Fisgas, Braga', 'Rita Alves', '2010-07-01', 'rae01@hotmail.com'),
        ('Joana Cunha', 135, 'Avenida Mateus Damasio, Braga', 'Marta Cunha', '2010-07-13', 'mce13@gmail.com'),
        ('Teresa Fidalgo', 136, 'Rua dos Peregrinos, Braga', 'Luis Fidalgo', '2011-08-11', 'lfe11@hotmail.com'),
        ('Rita Montenegro', 137, 'Rua da Mila, Braga', 'Andre Montenegro', '2011-08-20', 'ame20@hotmail.com'),
        ('Rui Meireles', 138, 'Rua de Barros, Braga', 'Torcato Meireles', '2011-01-29', 'tme29@hotmail.com'),
        ('Vasco Santos', 139, 'Rua de Vasconcelos, Braga', 'Afonso Santos', '2011-02-09', 'ase09@gmail.com'),
        ('Miguel Barroso', 140, 'Avenida dos Orfaos, Braga', 'Margarida Barroso', '2011-05-03', 'mbe03@hotmail.com'),
        ('Ines Sousa', 141, 'Rua Nova, Braga', 'Diana Sousa', '2011-12-25', 'dse12@sapo.pt');
        
INSERT INTO telefoneAluno
	(idtelefoneAluno, Telefone, Aluno_Numero)
    VALUES
		(1, 917859685, 118),
        (2, 968857892, 118),
        (3, 921913981, 119),
        (4, 960910973, 120),
        (5, 919983218, 121),
        (6, 910099320, 122),
        (7, 969989863, 123),
        (8, 911233889, 124),
        (9, 922229023, 125),
        (10, 917859685, 126),
        (11, 917402369, 127),
        (12, 929937230, 128),
        (13, 919741202, 129),
        (14, 920092380, 130),
        (15, 968912306, 131),
        (16, 968213041, 131),
        (17, 961239412, 132),
        (18, 920892382, 133),
        (19, 939954927, 134),
        (20, 960090293, 135),
        (21, 910093232, 136),
        (22, 930992772, 137),
        (23, 937813139, 138),
        (24, 910093273, 138),
        (25, 969872899, 139),
        (26, 967777823, 140),
        (27, 919971237, 141);
        

INSERT INTO Professor
    ( Numero, Data_Nasc, Nome, Morada, email)
    VALUES 
        (1, '1980-05-13', 'Rui Soares', 'Rua dos Perdigueiros, Guimaraes', 'rsp13@gmail.com'),
        (2, '1975-09-25', 'Maria Goncalves', 'Rua dos Canteiros, Porto', 'mgp25@gmail.com'),
        (3, '1986-03-02', 'Rita Costa', 'Rua das Flores, Braga', 'rcp2@gmail.com'),
        (4, '1970-08-30', 'Mario Rodrigues', 'Avenida Santa Maria, Guimaraes', 'mrp30@gmail.com');

        
INSERT INTO telefoneProf
	(idtelefoneProf, Telefone, Professor_Numero)
    VALUES
		(1, 916788545, 1),
        (2, 916788545, 2),
        (3, 937712382, 3),
        (4, 919123548, 4),
        (5, 916788545, 4); 
   
INSERT INTO Turma
	(idTurma, Numero, Sala, Ano, Professor_Numero)
    VALUES
		(1, 4, 14, 1, 1),
		(2, 5, 23, 2, 1),
        (3, 6, 14, 1, 2),
		(4, 7, 14, 3, 1),
        (5, 8, 16, 2, 2),
        (6, 9, 20, 1, 3),
		(7, 10, 20, 4, 1),
        (8, 11, 14, 3, 2),
        (9, 12, 16, 2, 3),
        (10, 13, 23, 1, 4);      
 
/* 
DELETE FROM Disciplina
where idDisc > 0; 
*/

 INSERT INTO Disciplina
	(idDisc, Nome, Programa, cargaHoraria)
    VALUES
		(1, 'Lingua Portuguesa 4Ano' ,'Educacao Literaria, Gramatica' , 9),
        (2, 'Estudo do Meio 4Ano', 'Descoberta de si mesmo, Descoberta dos Outros e Instituicoes, Ambiente Natural, Inter-relacoes entre Espacos, Materiais e Objetos', 4),
        (3, 'Matematica 4Ano', 'Numeros e Operacoes, Geometria e Medida, Organizacao e Tratamento de Dados', 9),
        (4, 'Lingua Portuguesa 3Ano', 'Educacao Literaria, Gramatica', 9),
        (5, 'Estudo do Meio 3Ano', 'Descoberta de si mesmo, Descoberta dos Outros e Instituicoes, Ambiente Natural, Inter-relacoes entre Espacos, Materiais e Objetos', 4),
        (6, 'Matematica 3Ano', 'Numeros e Operacoes, Geometria e Medida, Organizacao e Tratamento de Dados', 9),
        (7, 'Lingua Portuguesa 2Ano', 'Educacao Literaria, Gramatica', 9),
        (8, 'Estudo do Meio 2Ano', 'Descoberta de si mesmo, Descoberta dos Outros e Instituicoes, Ambiente Natural, Inter-relacoes entre Espacos, Materiais e Objetos', 4),
        (9, 'Matematica 2Ano', 'Numeros e Operacoes, Geometria e Medida, Organizacao e Tratamento de Dados', 9),
        (10, 'Lingua Portuguesa 1Ano', 'Educacao Literaria, Gramatica', 9),
        (11, 'Estudo do Meio 1Ano', 'Descoberta de si mesmo, Descoberta dos Outros e Instituicoes, Ambiente Natural, Inter-relacoes entre Espacos, Materiais e Objetos', 4),
        (12, 'Matematica 1Ano', 'Numeros e Operacoes, Geometria e Medida, Organizacao e Tratamento de Dados', 9);          
   
INSERT INTO Inscricao
	(idInscricao, AnoLetivo, Aluno_Numero, Turma_idTurma)
    VALUES
		(1, '14/15', 118, 1),
        (2, '14/15', 119, 1),
        (3, '14/15', 120, 1),
        (4, '14/15', 121, 1),
        (5, '14/15', 122, 1),
        (6, '15/16', 118, 2),
        (7, '15/16', 119, 2),
        (8, '15/16', 120, 2),
        (9, '15/16', 121, 2),
        (10, '15/16', 122, 2),
        (11, '15/16', 123, 2),
        (12, '15/16', 124, 3),
        (13, '15/16', 125, 3),
        (14, '15/16', 126, 3),
        (15, '15/16', 127, 3),
        (16, '15/16', 128, 3),
        (17, '16/17', 118, 4),
        (18, '16/17', 119, 4),
        (19, '16/17', 120, 4),
        (20, '16/17', 121, 4),
        (21, '16/17', 122, 4),
        (22, '16/17', 123, 4),
        (23, '16/17', 124, 5),
        (24, '16/17', 125, 5),
        (25, '16/17', 126, 5),
        (26, '16/17', 127, 5),
        (27, '16/17', 128, 5),
        (28, '16/17', 129, 5),
        (29, '16/17', 130, 6),
        (30, '16/17', 131, 6),
        (31, '16/17', 132, 6),
        (32, '16/17', 133, 6),
        (33, '16/17', 134, 6),
        (34, '16/17', 135, 6),
        (35, '17/18', 118, 7),
        (36, '17/18', 119, 7),
        (37, '17/18', 120, 7),
        (38, '17/18', 122, 7),
        (39, '17/18', 123, 7),
        (40, '17/18', 124, 8),
        (41, '17/18', 125, 8),
        (42, '17/18', 126, 8),
        (43, '17/18', 121, 8),
        (44, '17/18', 127, 8),
        (45, '17/18', 129, 8),
        (46, '17/18', 130, 9),
        (47, '17/18', 131, 9),
        (48, '17/18', 132, 9),
        (49, '17/18', 128, 9),
        (50, '17/18', 133, 9),
        (51, '17/18', 134, 9),
        (52, '17/18', 135, 9),
		(53, '17/18', 136, 10),
        (54, '17/18', 137, 10),
        (55, '17/18', 138, 10),
        (56, '17/18', 139, 10),
        (57, '17/18', 140, 10),
        (58, '17/18', 141, 10);

INSERT INTO Turma_has_Disciplina
	(Turma_idTurma,Disciplina_idDisc)
    VALUES
		(1,10),
        (1,11),
        (1,12),
        (2,7),
        (2,8),
        (2,9),
        (3,10),
        (3,11),
        (3,12),
        (4,4),
        (4,5),
        (4,6),
        (5,7),
        (5,8),
        (5,9),
		(6,10),
        (6,11),
        (6,12),
		(7,1),
        (7,2),
        (7,3),
		(8,4),
        (8,5),
        (8,6),
		(9,7),
        (9,8),
        (9,9),
		(10,10),
        (10,11),
        (10,12);
        
 /*        
DELETE FROM Avaliacao
where idAvaliacao > 0;
*/

INSERT INTO Avaliacao
	(idAvaliacao, Data, Nota, Tipo, Disciplina_idDisc, peso, Inscricao_idInscricao, Tema)
    VALUES
		
		(1, '2016-11-10', 55, 'Mini-teste', 1, 10, 1, 'Educacao Literaria'),
        (2, '2016-11-10', 67, 'Mini-teste', 1, 10, 2,  'Educacao Literaria'),
        (3, '2016-11-10', 14, 'Mini-teste', 1, 10, 3,  'Educacao Literaria'),
        (4, '2016-11-10', 85, 'Mini-teste', 1, 10, 4,  'Educacao Literaria'),
        (5, '2016-11-10', 89, 'Mini-teste', 1, 10, 5,  'Educacao Literaria'),
		(6, '2016-09-21', 70, 'Teste', 2, 20, 1,  'Descoberta de si mesmo'),
        (7, '2016-09-21', 68, 'Teste', 2, 20, 2, 'Descoberta de si mesmo'),
        (8, '2016-09-21', 34, 'Teste', 2, 20, 3,  'Descoberta de si mesmo'),
        (9, '2016-09-21', 65, 'Teste', 2, 20, 4,  'Descoberta de si mesmo'),
        (10, '2016-11-24', 87, 'Teste', 2, 20, 5,  'Descoberta de si mesmo'),
		(11, '2016-11-24', 10, 'Teste', 2, 20, 6,  'Descoberta de si mesmo'),
		(12, '2016-11-24', 96, 'Ficha', 3, 5, 1,  'Numeros e Operacoes'),
        (13, '2016-11-24', 05, 'Ficha', 3, 5, 2,  'Numeros e Operacoes'),
        (14, '2016-11-24', 87, 'Ficha', 3, 5, 3,  'Numeros e Operacoes'),
        (15, '2016-11-24', 95, 'Ficha', 3, 5, 4,  'Numeros e Operacoes'),
        (16, '2016-11-24', 34, 'Ficha', 3, 5, 5,  'Numeros e Operacoes'),
        (17, '2016-11-24', 69, 'Ficha', 3, 5, 6,  'Numeros e Operacoes'),
        (18, '2016-11-24', 59, 'Ficha', 3, 5, 7,  'Numeros e Operacoes'),
		(19, '2017-11-15', 80, 'Ficha', 1, 1, 35, 'Educacao Literaria'),
        (20, '2017-10-10', 94, 'Teste', 2, 15, 35,  'Ambiente Natural'),
        (21, '2017-12-06', 75, 'Teste', 3, 10, 35,  'Geometria e Medida'),
        (22, '2017-11-15', 50, 'Ficha', 1, 1, 36,  'Educacao Literaria'),
        (23, '2017-10-10', 70, 'Teste', 2, 15, 36,  'Ambiente Natural'),
        (24, '2017-12-06', 83, 'Teste', 3, 10, 36,  'Geometria e Medida'),
        (25, '2017-11-15', 55, 'Ficha', 1, 1, 37,  'Educacao Literaria'),
        (26, '2017-10-10', 20, 'Teste', 2, 15, 37,  'Ambiente Natural'),
        (27, '2017-12-06', 48, 'Teste', 3, 10, 37,  'Geometria e Medida'),
        (28, '2017-11-15', 67, 'Ficha', 1, 1, 38,  'Educacao Literaria'),
        (29, '2017-10-10', 78, 'Teste', 2, 15, 38,  'Ambiente Natural'),
        (30, '2017-12-06', 70, 'Teste', 3, 10, 38,  'Geometria e Medida'),
        (31, '2017-11-15', 98, 'Ficha', 1, 1, 39,  'Educacao Literaria'),
        (32, '2017-10-10', 79, 'Teste', 2, 15, 39,  'Ambiente Natural'),
        (33, '2017-12-06', 80, 'Teste', 3, 10, 39,  'Geometria e Medida'),
        (34, '2017-11-20', 55, 'Teste', 1, 15, 40,  'Gramatica'),
        (35, '2017-09-29', 20, 'Teste', 2, 15, 40,  'Descoberta de si mesmo'),
        (36, '2017-12-09', 48, 'Teste', 3, 10, 40,  'Numeros e Operacoes'),
        (37, '2017-11-20', 80, 'Teste', 1, 15, 41,  'Gramatica'),
        (38, '2017-09-29', 56, 'Teste', 2, 15, 41,  'Descoberta de si mesmo'),
        (39, '2017-12-09', 72, 'Teste', 3, 10, 41,  'Numeros e Operacoes'),
        (40, '2017-11-20', 92, 'Teste', 1, 15, 42,  'Gramatica'),
        (41, '2017-09-29', 30, 'Teste', 2, 15, 42,  'Descoberta de si mesmo'),
        (42, '2017-12-09', 45, 'Teste', 3, 10, 42,  'Numeros e Operacoes'),
        (43, '2017-11-20', 90, 'Teste', 1, 15, 43,  'Gramatica'),
        (44, '2017-09-29', 94, 'Teste', 2, 15, 43,  'Descoberta de si mesmo'),
        (45, '2017-12-09', 88, 'Teste', 3, 10, 43,  'Numeros e Operacoes'),
        (46, '2017-11-20', 79, 'Teste', 1, 15, 44,  'Gramatica'),
        (47, '2017-09-29', 23, 'Teste', 2, 15, 44,  'Descoberta de si mesmo'),
        (48, '2017-12-09', 44, 'Teste', 3, 10, 44,  'Numeros e Operacoes'),
        (49, '2017-11-20', 96, 'Teste', 1, 15, 45,  'Gramatica'),
        (50, '2017-09-29', 100, 'Teste', 2, 15, 45,  'Descoberta de si mesmo'),
        (51, '2017-12-09', 90, 'Teste', 3, 10, 45,  'Numeros e Operacoes'),
        (52, '2017-11-01', 96, 'Ficha', 1, 2, 46,  'Educacao Literaria'),
        (53, '2017-09-07', 89, 'Teste', 2, 10, 46,  'Descoberta dos outros e das Instituicoes'),
        (54, '2017-12-04', 99, 'Ficha', 3, 4, 46,  'Numeros e Operacoes'),
        (55, '2017-11-01', 78, 'Ficha', 1, 2, 47,  'Educacao Literaria'),
        (56, '2017-09-07', 96, 'Teste', 2, 10, 47,  'Descoberta dos outros e das Instituicoes'),
        (57, '2017-12-04', 76, 'Ficha', 3, 4, 47,  'Numeros e Operacoes'),
        (58, '2017-11-01', 65, 'Ficha', 1, 2, 48,  'Educacao Literaria'),
        (59, '2017-09-07', 98, 'Teste', 2, 10, 48,  'Descoberta dos outros e das Instituicoes'),
        (60, '2017-12-04', 79, 'Ficha', 3, 4, 48,  'Numeros e Operacoes'),
        (61, '2017-11-01', 66, 'Ficha', 1, 2, 49,  'Educacao Literaria'),
        (62, '2017-09-07', 92, 'Teste', 2, 10, 49,  'Descoberta dos outros e das Instituicoe'),
        (63, '2017-12-04', 66, 'Ficha', 3, 4, 49, 'Numeros e Operacoes'),
        (64, '2017-11-01', 67, 'Ficha', 1, 2, 50,  'Educacao Literaria'),
        (65, '2017-09-07', 42, 'Teste', 2, 10, 50,  'Descoberta dos outros e das Instituicoes'),
        (66, '2017-12-04', 87, 'Ficha', 3, 4, 50,  'Numeros e Operacoes'),
        (67, '2017-11-01', 56, 'Ficha', 1, 2, 51,  'Educacao Literaria'),
        (68, '2017-09-07', 65, 'Teste', 2, 10, 51,  'Descoberta dos outros e das Instituicoes'),
        (69, '2017-12-04', 54, 'Ficha', 3, 4, 51, 'Numeros e Operacoes'),
        (70, '2017-11-01', 90, 'Ficha', 1, 2, 52,  'Educacao Literaria'),
        (71, '2017-09-07', 87, 'Teste', 2, 10, 52,  'Descoberta dos outros e das Instituicoes'),
        (72, '2017-12-04', 77, 'Ficha', 3, 4, 52, 'Numeros e Operacoes'),
        (73, '2017-11-17', 50, 'Teste', 1, 15, 53,  'Gramatica'),
        (74, '2017-09-18', 60, 'Ficha', 2, 5, 53,  'Descoberta dos Materiais e Objetos'),
        (75, '2017-12-09', 67, 'Teste', 3, 15, 53,  'Adicao e Subtracao'),
        (76, '2017-11-17', 89, 'Teste', 1, 15, 54,  'Gramatica'),
        (77, '2017-09-18', 88, 'Ficha', 2, 5, 54,  'Descoberta dos Materiais e Objetos'),
        (78, '2017-12-09', 92, 'Teste', 3, 15, 54,  'Adicao e Subtracao'),
        (79, '2017-11-17', 56, 'Teste', 1, 15, 55,  'Gramatica'),
        (80, '2017-09-18', 67, 'Ficha', 2, 5, 55,  'Descoberta dos Materiais e Objetos'),
        (81, '2017-12-09', 59, 'Teste', 3, 15, 55,  'Adicao e Subtracao'),
        (82, '2017-11-17', 90, 'Teste', 1, 15, 56,  'Gramatica'),
        (83, '2017-09-18', 97, 'Ficha', 2, 5, 56,  'Descoberta dos Materiais e Objetos'),
        (84, '2017-12-09', 89, 'Teste', 3, 15, 56,  'Adicao e Subtracao'),
        (85, '2017-11-17', 54, 'Teste', 1, 15, 57, 'Gramatica'),
        (86, '2017-09-18', 34, 'Ficha', 2, 5, 57, 'Descoberta dos Materiais e Objetos'),
        (87, '2017-12-09', 56, 'Teste', 3, 15, 57,  'Adicao e Subtracao'),
        (88, '2017-11-17', 89, 'Teste', 1, 15, 58,  'Gramatica'),
        (89, '2017-09-18', 95, 'Ficha', 2, 5, 58,  'Descoberta dos Materiais e Objetos'),
        (90, '2017-12-09', 100, 'Teste', 3, 15, 58,  'Adicao e Subtracao');


/* DROP PROCEDURE AVALIACAO_ALUNO_MOMENTO; */

DELIMITER $$

CREATE PROCEDURE AVALIACAO_ALUNO_MOMENTO( IN ID_INSC int)
BEGIN

SELECT Aluno.Nome, inscricao.AnoLetivo, disciplina.Nome AS Disciplina FROM inscricao
	JOIN Aluno ON Aluno.Numero = inscricao.Aluno_Numero
    JOIN avaliacao ON avaliacao.Inscricao_idInscricao = inscricao.idInscricao
    JOIN disciplina ON disciplina.idDisc = avaliacao.Disciplina_idDisc
    where Inscricao.idInscricao = ID_INSC;
    
END $$

call AVALIACAO_ALUNO_MOMENTO(1);

/* DROP PROCEDURE NOME_PROFESSOR; */

DELIMITER $$

CREATE PROCEDURE NOME_PROFESSOR ( IN ALUNO_NUMERO int)
BEGIN

SELECT inscricao.AnoLetivo, professor.Nome FROM Aluno
JOIN inscricao ON Aluno.Numero = inscricao.Aluno_Numero
JOIN turma ON turma.idTurma = inscricao.Turma_idTurma
JOIN professor ON professor.Numero = turma.Professor_Numero
where Aluno.Numero = ALUNO_NUMERO;

END $$

call NOME_PROFESSOR(118);

DELIMITER $$

/* adicionar inscricao */

DELIMITER $$

CREATE PROCEDURE `transaction_inscricao`()

BEGIN
DECLARE exit handler for sqlexception
BEGIN
ROLLBACK;
END;

DECLARE exit handler for sqlwarning
BEGIN
ROLLBACK;
END;

START TRANSACTION;

INSERT INTO Inscricao (idInscricao, AnoLetivo, Aluno_Numero, Turma_idTurma)
VALUES (59, '14/15', 122, 2);

COMMIT;
END $$

DELIMITER $$

/*  Realizar a insercao de um aluno */

DELIMITER $$

CREATE PROCEDURE `transaction_insercao_aluno`()

BEGIN
DECLARE exit handler for sqlexception
BEGIN
ROLLBACK;
END;

DECLARE exit handler for sqlwarning
BEGIN
ROLLBACK;
END;

START TRANSACTION;

INSERT INTO Aluno (Nome, Numero, Morada, Encarregado, Data_Nasc, Email)
VALUES ('Luis Costa', 142, 'Rua da Portela, Braga', 'Manuel Costa', '2008-03-31', 'lc7@hotmail.com');
INSERT INTO Inscricao (idInscricao, AnoLetivo, Aluno_Numero, Turma_idTurma)
VALUES (60, '17/18', 123, 1);
INSERT INTO telefoneAluno (idtelefoneAluno, Telefone, Aluno_Numero)
VALUES (28, 917766776, 123);

COMMIT;
END $$

/* call transaction_insercao_aluno(); */
/*
CREATE VIEW profView AS 
SELECT p.Numero, p.Nome, p.email, t.Telefone FROM Professor AS p   
JOIN telefoneProf AS t ON (t.Professor_Numero = p.Numero);

/* SELECT * FROM profView; */
/*
CREATE VIEW turmaView AS 
SELECT Sala, Numero, Ano, AnoLetivo FROM Inscricao  
JOIN Turma ON Turma.idTurma = Inscricao.Turma_idTurma;

/* SELECT * FROM turmaView; */

/* DROP USER Aluno; */
/*
CREATE USER 'Admin' IDENTIFIED BY 'Joaquim';
SET PASSWORD FOR 'Admin' = '1234';

CREATE USER 'Professor' IDENTIFIED BY 'Joao'
WITH MAX_QUERIES_PER_HOUR 50;

SET PASSWORD FOR 'Professor' = '4321';


CREATE USER 'Aluno' IDENTIFIED BY 'Luis'
WITH MAX_QUERIES_PER_HOUR 20;
SET PASSWORD FOR 'Aluno' = '0000';


GRANT ALL ON Aluno TO 'Admin';

GRANT SELECT ON Aluno TO 'Professor',

GRANT USAGE ON inscricao TO 'Aluno';
